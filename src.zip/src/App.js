import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="App-header">Lloyds Bank</header>

      <main className="App-main">
        <h2>Welcome to Lloyds Bank</h2>
        <p>Fill in the details below and select the required options.</p>

        <form>
          <label htmlFor="name">Full Name:</label>
          <input type="text" id="name" placeholder="Enter your name" />

          <label htmlFor="email">Email:</label>
          <input type="email" id="email" placeholder="Enter your email" />

          <label htmlFor="account-type">Account Type:</label>
          <select id="account-type">
            <option value="savings">Savings</option>
            <option value="current">Current</option>
            <option value="business">Business</option>
          </select>

          <label htmlFor="branch">Select Branch:</label>
          <select id="branch">
            <option value="london">London</option>
            <option value="manchester">Manchester</option>
            <option value="birmingham">Birmingham</option>
          </select>

          <button type="submit">Submit</button>
        </form>

        <div className="links">
          <a href="#">Learn More</a>
          <a href="#">Contact Support</a>
        </div>
      </main>

      <footer className="App-footer">
        © 2025 Lloyds Bank. All Rights Reserved.
      </footer>
    </div>
  );
}

export default App;
